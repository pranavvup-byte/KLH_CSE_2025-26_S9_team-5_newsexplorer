import { FiInbox } from 'react-icons/fi'
import './EmptyState.css'

export default function EmptyState({ icon, title, description, action }) {
  const Icon = icon || FiInbox
  return (
    <div className="empty-state">
      <div className="empty-state__icon">
        <Icon />
      </div>
      <h3 className="empty-state__title">{title}</h3>
      {description && <p className="empty-state__desc">{description}</p>}
      {action && <div className="empty-state__action">{action}</div>}
    </div>
  )
}
