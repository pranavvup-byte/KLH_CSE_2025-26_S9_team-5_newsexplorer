import articles, { CATEGORIES, CATEGORY_META } from '../data/articles.js'
import {
  buildTfIdfModel,
  buildVocabulary,
  rankByQuery,
  rankSimilarArticles,
  getFuzzySuggestion,
  phraseSearch as kmpPhraseSearch,
} from '../utils/textAlgorithms.js'

// Built once when the app loads — this stands in for the index the Java
// backend builds at startup (inverted index + TF-IDF vectors).
const tfIdfModel = buildTfIdfModel(articles)
const vocabulary = buildVocabulary(articles)

// Small helper to simulate real network latency so loading states have
// something to show during a demo.
const delay = (ms = 350) => new Promise((resolve) => setTimeout(resolve, ms))

/**
 * search(query, topN) — ranks articles by TF-IDF + cosine similarity.
 * Mirrors the Java backend's `search(query, topN)`.
 */
export async function searchArticles(query, { topN = 50, category = 'All', sortBy = 'relevance', exactPhrase = false } = {}) {
  await delay()

  if (!query || !query.trim()) {
    let results = articles.map((article) => ({ article, score: 1 }))
    if (category !== 'All') results = results.filter((r) => r.article.category === category)
    return applySort(results, sortBy).slice(0, topN)
  }

  let ranked
  if (exactPhrase) {
    ranked = kmpPhraseSearch(query, articles).map((article) => ({ article, score: 1 }))
  } else {
    ranked = rankByQuery(query, articles, tfIdfModel)
  }

  if (category !== 'All') {
    ranked = ranked.filter((r) => r.article.category === category)
  }

  return applySort(ranked, sortBy).slice(0, topN)
}

function applySort(results, sortBy) {
  const copy = [...results]
  if (sortBy === 'latest') {
    copy.sort((a, b) => new Date(b.article.date) - new Date(a.article.date))
  } else if (sortBy === 'oldest') {
    copy.sort((a, b) => new Date(a.article.date) - new Date(b.article.date))
  } else {
    copy.sort((a, b) => b.score - a.score)
  }
  return copy
}

/** getFuzzySuggestion(query) — Damerau-Levenshtein "Did you mean?" suggestion. */
export async function getFuzzySuggestions(query) {
  await delay(150)
  if (!query || query.trim().split(/\s+/).length > 4) return null
  return getFuzzySuggestion(query, vocabulary)
}

/** getArticleById(id) */
export async function getArticleById(id) {
  await delay(200)
  return articles.find((a) => a.id === id) || null
}

/**
 * recommend(articleId, topN) — TF-IDF + cosine similarity between articles.
 * Mirrors the Java backend's `recommend(articleId, topN)`.
 */
export async function getRecommendations(articleId, topN = 4) {
  await delay(250)
  return rankSimilarArticles(articleId, articles, tfIdfModel, topN)
}

/** Personalized recommendations from a set of selected interest categories. */
export async function getRecommendationsForInterests(interests, topN = 8) {
  await delay(300)
  if (!interests || interests.length === 0) {
    return [...articles].sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, topN)
  }
  return articles
    .filter((a) => interests.includes(a.category))
    .sort((a, b) => new Date(b.date) - new Date(a.date))
    .slice(0, topN)
}

/** categories() — category list with live counts and a featured article each. */
export async function getCategories() {
  await delay(200)
  return CATEGORIES.map((name) => {
    const inCategory = articles.filter((a) => a.category === name)
    const sorted = [...inCategory].sort((a, b) => new Date(b.date) - new Date(a.date))
    return {
      name,
      description: CATEGORY_META[name]?.description || '',
      count: inCategory.length,
      featured: sorted[0] || null,
      recent: sorted.slice(1, 5),
    }
  })
}

export async function getArticlesByCategory(category) {
  await delay(250)
  return articles
    .filter((a) => a.category === category)
    .sort((a, b) => new Date(b.date) - new Date(a.date))
}

export async function getLatestArticles(limit = 6) {
  await delay(250)
  return [...articles].sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, limit)
}

export async function getTrendingTopics() {
  await delay(100)
  return CATEGORIES
}

export { CATEGORIES }
