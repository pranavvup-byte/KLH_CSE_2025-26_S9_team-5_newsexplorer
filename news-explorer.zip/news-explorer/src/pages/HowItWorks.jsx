import { useMemo, useState } from 'react'
import { FiSearch, FiArrowRight } from 'react-icons/fi'
import {
  tokenize,
  damerauLevenshtein,
  kmpSearch,
} from '../utils/textAlgorithms.js'
import './HowItWorks.css'

const SEARCH_PIPELINE = [
  { title: 'Article collection', detail: 'Every article is stored with its title, description and full text.' },
  { title: 'Text tokenization', detail: 'Text is lowercased and split into individual words.' },
  { title: 'Stopword removal', detail: 'Common words like "the", "is" and "and" are dropped — they carry no search meaning.' },
  { title: 'Inverted index', detail: 'Each remaining word is mapped to the set of articles it appears in, so lookups are fast.' },
  { title: 'TF-IDF', detail: 'Every word is weighted by how often it appears in an article versus how rare it is across all articles.' },
  { title: 'Cosine similarity', detail: 'The search query is turned into the same kind of weighted vector, then compared against every article.' },
  { title: 'Ranked search results', detail: 'Articles are sorted by similarity score, most relevant first.' },
  { title: 'Recommendations', detail: 'The same similarity comparison, run article-to-article, powers "You may also like".' },
]

const FUZZY_PIPELINE = [
  'User query',
  'Damerau-Levenshtein distance',
  'Closest known terms',
  '"Did you mean?"',
]

const CATEGORY_PIPELINE = [
  'Article text',
  'Keyword matching',
  'Topic score per category',
  'Category assigned',
]

const TOKENIZE_EXAMPLE = 'The Central Bank Holds Interest Rates Steady'
const FUZZY_EXAMPLE_WORD = 'inteligence'
const FUZZY_EXAMPLE_CANDIDATES = ['intelligence', 'inference', 'interest']
const PHRASE_EXAMPLE_TEXT =
  'The central bank kept its benchmark interest rate unchanged this week, citing lingering uncertainty in labor markets.'

export default function HowItWorks() {
  const [phraseQuery, setPhraseQuery] = useState('interest rate')

  const tokens = useMemo(() => tokenize(TOKENIZE_EXAMPLE), [])

  const fuzzyDistances = useMemo(
    () =>
      FUZZY_EXAMPLE_CANDIDATES.map((word) => ({
        word,
        distance: damerauLevenshtein(FUZZY_EXAMPLE_WORD, word),
      })).sort((a, b) => a.distance - b.distance),
    [],
  )

  const phraseFound = useMemo(
    () => (phraseQuery.trim() ? kmpSearch(PHRASE_EXAMPLE_TEXT.toLowerCase(), phraseQuery.trim().toLowerCase()) : false),
    [phraseQuery],
  )

  return (
    <div className="page container how-it-works">
      <div className="page-heading">
        <h1>How News Explorer works</h1>
        <p>
          A quick look under the hood — this is the same pipeline the Java backend runs, shown here with small
          live demos so you can walk through it during your presentation.
        </p>
      </div>

      {/* ---------------- Search & ranking pipeline ---------------- */}
      <section className="hiw-section">
        <h2>Search &amp; ranking pipeline</h2>
        <p className="hiw-section__intro">
          From a raw article to a ranked list of search results, every article passes through the same steps.
        </p>

        <div className="hiw-flow hiw-flow--vertical">
          {SEARCH_PIPELINE.map((step, index) => (
            <div className="hiw-flow__row" key={step.title}>
              <div className="hiw-flow__node">{index + 1}</div>
              <div className="hiw-flow__text">
                <h3>{step.title}</h3>
                <p>{step.detail}</p>
              </div>
              {index < SEARCH_PIPELINE.length - 1 && <div className="hiw-flow__line" aria-hidden="true" />}
            </div>
          ))}
        </div>
      </section>

      {/* ---------------- Tokenization + stopwords live demo ---------------- */}
      <section className="hiw-section">
        <h2>Tokenization &amp; stopword removal, live</h2>
        <p className="hiw-section__intro">
          Here's what actually happens to a real headline from the archive:
        </p>
        <div className="hiw-demo">
          <div className="hiw-demo__label">Original text</div>
          <p className="hiw-demo__sentence">"{TOKENIZE_EXAMPLE}"</p>
          <div className="hiw-demo__label">Tokens kept after lowercasing, splitting and stopword removal</div>
          <div className="hiw-token-row">
            {tokens.map((token) => (
              <span key={token} className="hiw-token">{token}</span>
            ))}
          </div>
          <p className="hiw-demo__note">
            Meaningful words like "central", "bank" and "steady" are kept, while connector words like "the" and
            "its" are removed — the inverted index only ever stores these kept tokens.
          </p>
        </div>
      </section>

      {/* ---------------- TF-IDF + cosine similarity ---------------- */}
      <section className="hiw-section">
        <h2>TF-IDF + cosine similarity</h2>
        <p className="hiw-section__intro">
          TF-IDF gives every word in an article a weight: high if the word appears often in that article but
          rarely elsewhere, low if it's common everywhere. Turning both the search query and every article into
          a weighted vector lets us measure how close they are using cosine similarity — the same score shown
          as a "% match" next to search results and recommendations.
        </p>
        <div className="hiw-formula-card">
          <div className="hiw-formula">
            <span>TF-IDF(term)</span>
            <FiArrowRight />
            <span>(term frequency in article) × log(N / articles containing term)</span>
          </div>
          <div className="hiw-formula">
            <span>cosine(A, B)</span>
            <FiArrowRight />
            <span>(A · B) / (‖A‖ × ‖B‖)</span>
          </div>
        </div>
        <p className="hiw-demo__note">
          A cosine similarity close to 1 means two pieces of text share many important weighted words — that's
          why it works well both for "query vs. article" search and "article vs. article" recommendations.
        </p>
      </section>

      {/* ---------------- Fuzzy matching live demo ---------------- */}
      <section className="hiw-section">
        <h2>Fuzzy search — "Did you mean?"</h2>
        <div className="hiw-flow hiw-flow--horizontal">
          {FUZZY_PIPELINE.map((step, index) => (
            <div className="hiw-flow__chip-row" key={step}>
              <div className="hiw-flow__chip">{step}</div>
              {index < FUZZY_PIPELINE.length - 1 && <FiArrowRight className="hiw-flow__arrow" />}
            </div>
          ))}
        </div>

        <div className="hiw-demo">
          <p className="hiw-section__intro" style={{ marginTop: 20 }}>
            Damerau-Levenshtein distance counts the fewest insertions, deletions, substitutions or adjacent
            swaps needed to turn one word into another. The smaller the distance, the more likely it's a typo of
            a real term in the archive.
          </p>
          <div className="hiw-demo__label">Misspelled query: "{FUZZY_EXAMPLE_WORD}"</div>
          <div className="hiw-distance-list">
            {fuzzyDistances.map(({ word, distance }, index) => (
              <div className={`hiw-distance-row ${index === 0 ? 'hiw-distance-row--best' : ''}`} key={word}>
                <span className="hiw-distance-word">{word}</span>
                <span className="hiw-distance-bar-track">
                  <span
                    className="hiw-distance-bar"
                    style={{ width: `${Math.max(12, 100 - distance * 25)}%` }}
                  />
                </span>
                <span className="hiw-distance-value">distance {distance}</span>
              </div>
            ))}
          </div>
          <p className="hiw-demo__note">
            The closest match, <strong>{fuzzyDistances[0].word}</strong>, is offered as the "Did you mean?"
            suggestion on the Explore page.
          </p>
        </div>
      </section>

      {/* ---------------- KMP phrase search live demo ---------------- */}
      <section className="hiw-section">
        <h2>Exact phrase search (KMP)</h2>
        <p className="hiw-section__intro">
          The Knuth-Morris-Pratt algorithm scans an article's text for an exact phrase in linear time, without
          re-checking characters it has already matched. Try it against a real sentence from the archive:
        </p>
        <div className="hiw-demo">
          <div className="hiw-demo__label">Sample article sentence</div>
          <p className="hiw-demo__sentence">"{PHRASE_EXAMPLE_TEXT}"</p>

          <div className="hiw-demo__label">Try an exact phrase</div>
          <div className="hiw-phrase-input">
            <FiSearch />
            <input
              type="text"
              value={phraseQuery}
              onChange={(event) => setPhraseQuery(event.target.value)}
              placeholder="e.g. interest rate"
            />
          </div>
          <div className={`hiw-phrase-result ${phraseFound ? 'hiw-phrase-result--found' : 'hiw-phrase-result--missing'}`}>
            {phraseFound ? 'Match found in the sentence above.' : 'No exact match in the sentence above.'}
          </div>
        </div>
      </section>

      {/* ---------------- Automatic categorization ---------------- */}
      <section className="hiw-section">
        <h2>Automatic categorization</h2>
        <p className="hiw-section__intro">
          Every article is sorted into a category without a human tagging it by hand.
        </p>
        <div className="hiw-flow hiw-flow--horizontal">
          {CATEGORY_PIPELINE.map((step, index) => (
            <div className="hiw-flow__chip-row" key={step}>
              <div className="hiw-flow__chip">{step}</div>
              {index < CATEGORY_PIPELINE.length - 1 && <FiArrowRight className="hiw-flow__arrow" />}
            </div>
          ))}
        </div>
        <p className="hiw-demo__note">
          Each category has a set of representative keywords (for example, "vaccine" and "hospital" for Health,
          or "tournament" and "league" for Sports). An article's text is scored against every category's
          keyword set, and it's placed into whichever category scores highest — the same category pill you see
          on every article card.
        </p>
      </section>
    </div>
  )
}
