import { useEffect, useState } from 'react'
import { useParams, Link, useNavigate } from 'react-router-dom'
import { FiBookmark, FiShare2, FiClock, FiArrowLeft } from 'react-icons/fi'
import ArticleImage from '../components/ArticleImage.jsx'
import RecommendationCard from '../components/RecommendationCard.jsx'
import { getArticleById, getRecommendations } from '../services/newsService.js'
import { useSavedArticles } from '../hooks/useSavedArticles.js'
import { showToast } from '../hooks/useToast.js'
import './ArticleDetails.css'

function formatDate(dateStr) {
  return new Date(dateStr).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })
}

export default function ArticleDetails() {
  const { id } = useParams()
  const navigate = useNavigate()
  const [article, setArticle] = useState(null)
  const [related, setRelated] = useState([])
  const [loading, setLoading] = useState(true)
  const { isSaved, toggleSaved } = useSavedArticles()

  useEffect(() => {
    let active = true
    setLoading(true)
    getArticleById(id).then((found) => {
      if (!active) return
      setArticle(found)
      if (found) {
        getRecommendations(found.id, 4).then((recs) => active && setRelated(recs))
      }
      setLoading(false)
    })
    return () => {
      active = false
    }
  }, [id])

  if (loading) {
    return (
      <div className="page container article-details">
        <div className="skeleton" style={{ height: 24, width: 120, marginBottom: 20 }} />
        <div className="skeleton" style={{ height: 48, width: '80%', marginBottom: 16 }} />
        <div className="skeleton" style={{ height: 320, width: '100%', marginBottom: 24 }} />
      </div>
    )
  }

  if (!article) {
    return (
      <div className="page container article-details">
        <p>We couldn't find that article.</p>
        <Link to="/explore" className="btn btn-outline">Back to Explore</Link>
      </div>
    )
  }

  const saved = isSaved(article.id)

  const handleSave = () => {
    const nowSaved = toggleSaved(article.id)
    showToast(nowSaved ? 'Article saved' : 'Removed from saved')
  }

  const handleShare = async () => {
    const url = window.location.href
    if (navigator.share) {
      try {
        await navigator.share({ title: article.title, url })
      } catch {
        // user cancelled share sheet — nothing to do
      }
    } else {
      await navigator.clipboard.writeText(url)
      showToast('Link copied to clipboard')
    }
  }

  return (
    <div className="page">
      <div className="container article-details">
        <button className="back-link" onClick={() => navigate(-1)}>
          <FiArrowLeft /> Back
        </button>

        <span className={`category-pill ${article.category}`}>{article.category}</span>
        <h1 className="article-details__title">{article.title}</h1>

        <div className="article-details__meta">
          <span>{article.source}</span>
          <span className="dot">·</span>
          <span>By {article.author}</span>
          <span className="dot">·</span>
          <span>{formatDate(article.date)}</span>
          <span className="dot">·</span>
          <span className="reading-time"><FiClock /> {article.readingTime} min read</span>
        </div>

        <div className="article-details__actions">
          <button className={`btn btn-outline ${saved ? 'btn-outline--active' : ''}`} onClick={handleSave}>
            <FiBookmark /> {saved ? 'Saved' : 'Save article'}
          </button>
          <button className="btn btn-ghost" onClick={handleShare}>
            <FiShare2 /> Share
          </button>
        </div>

        <ArticleImage category={article.category} size="lg" />

        <div className="article-details__body">
          {article.content.split('\n\n').map((paragraph, index) => (
            <p key={index}>{paragraph}</p>
          ))}
        </div>

        {related.length > 0 && (
          <section className="related-section">
            <div className="related-section__header">
              <h2>You may also like</h2>
              <span className="related-section__label">Recommended based on article similarity</span>
            </div>
            <div className="related-section__grid">
              {related.map(({ article: rel, score }) => (
                <RecommendationCard key={rel.id} article={rel} score={score} />
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  )
}
