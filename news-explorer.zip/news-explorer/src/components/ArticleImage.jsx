import { FiCpu, FiActivity, FiTrendingUp, FiHeart, FiFlag } from 'react-icons/fi'
import './ArticleImage.css'

const ICONS = {
  Technology: FiCpu,
  Sports: FiActivity,
  Business: FiTrendingUp,
  Health: FiHeart,
  Politics: FiFlag,
}

export default function ArticleImage({ category, size = 'md' }) {
  const Icon = ICONS[category] || FiCpu
  return (
    <div className={`article-image article-image--${size} article-image--${category}`}>
      <Icon aria-hidden="true" />
    </div>
  )
}
