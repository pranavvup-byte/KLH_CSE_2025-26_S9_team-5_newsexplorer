import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { FiBookmark } from 'react-icons/fi'
import ArticleGrid from '../components/ArticleGrid.jsx'
import EmptyState from '../components/EmptyState.jsx'
import SearchBar from '../components/SearchBar.jsx'
import { useSavedArticles } from '../hooks/useSavedArticles.js'
import articles from '../data/articles.js'
import './Saved.css'

export default function Saved() {
  const { savedIds } = useSavedArticles()
  const [query, setQuery] = useState('')
  const [savedArticles, setSavedArticles] = useState([])

  useEffect(() => {
    const found = articles.filter((article) => savedIds.includes(article.id))
    setSavedArticles(found)
  }, [savedIds])

  const filtered = query.trim()
    ? savedArticles.filter((article) =>
        `${article.title} ${article.description}`.toLowerCase().includes(query.trim().toLowerCase()),
      )
    : savedArticles

  return (
    <div className="page container saved-page">
      <div className="page-heading">
        <h1>Saved articles</h1>
        <p>Everything you bookmark stays here, even after you close the tab.</p>
      </div>

      {savedArticles.length === 0 ? (
        <EmptyState
          icon={FiBookmark}
          title="Nothing saved yet"
          description="Tap the bookmark icon on any article to keep it here for later."
          action={
            <Link to="/explore" className="btn btn-primary">
              Browse articles
            </Link>
          }
        />
      ) : (
        <>
          <div className="saved-search">
            <SearchBar value={query} onChange={setQuery} onSubmit={() => {}} placeholder="Search your saved articles…" />
          </div>
          <ArticleGrid
            results={filtered.map((article) => ({ article }))}
            loading={false}
            emptyState={<EmptyState title="No matches in your saved articles" description="Try a different search term." />}
          />
        </>
      )}
    </div>
  )
}
