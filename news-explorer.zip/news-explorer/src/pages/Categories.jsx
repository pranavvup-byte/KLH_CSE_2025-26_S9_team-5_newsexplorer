import { useEffect, useState } from 'react'
import CategoryCard from '../components/CategoryCard.jsx'
import { getCategories } from '../services/newsService.js'
import './Categories.css'

export default function Categories() {
  const [categories, setCategories] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    getCategories().then((data) => {
      setCategories(data)
      setLoading(false)
    })
  }, [])

  return (
    <div className="page container categories-page">
      <div className="page-heading">
        <h1>Categories</h1>
        <p>
          Every article is sorted automatically — the backend scores each piece of text against category
          keywords and assigns whichever topic scores highest.
        </p>
      </div>

      {loading ? (
        <div className="category-list">
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="skeleton" style={{ height: 96, borderRadius: 16 }} />
          ))}
        </div>
      ) : (
        <div className="category-list">
          {categories.map((category) => (
            <CategoryCard key={category.name} category={category} />
          ))}
        </div>
      )}
    </div>
  )
}
