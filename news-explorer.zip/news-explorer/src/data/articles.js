// Sample corpus standing in for the article database. Swap `newsService.js`
// to fetch from a real API later and every page keeps working unchanged.

const articles = [
  {
    id: 'tech-1',
    title: 'AI Startup Raises Funding for New Chip Design',
    category: 'Technology',
    source: 'TechDaily',
    author: 'Priya Nandan',
    date: '2026-09-18',
    readingTime: 4,
    description: 'A Bengaluru-based startup has closed a new funding round to build chips tuned for on-device AI inference.',
    content: `A Bengaluru-based semiconductor startup has raised a new round of funding to build chips purpose-built for on-device artificial intelligence inference. The company says its architecture cuts power consumption significantly compared to general-purpose processors, making it attractive for laptops, phones, and edge sensors.

Investors pointed to growing demand for AI hardware that does not depend on constant cloud connectivity. The startup plans to use the funding to expand its engineering team and tape out its first commercial chip within eighteen months. Analysts say the chip design market has become intensely competitive as more companies race to serve the AI boom, with venture funding for hardware startups reaching levels not seen since the mobile chip era.

The founders, both former engineers at larger semiconductor firms, said the new capital will also go toward building a software toolkit that helps developers optimize AI models to run efficiently on the new chip.`,
    image: 'chip',
    tags: ['artificial intelligence', 'startup', 'chips', 'funding', 'hardware'],
  },
  {
    id: 'sports-1',
    title: 'National Cricket Team Wins Tournament Final',
    category: 'Sports',
    source: 'SportsWire',
    author: 'Arjun Mehta',
    date: '2026-09-20',
    readingTime: 3,
    description: 'A last-over finish sealed the title for the national side in front of a capacity crowd.',
    content: `The national cricket team claimed the tournament title after a tense final that went down to the last over. Chasing a target of 214, the side lost early wickets before a middle-order partnership steadied the innings and set up a dramatic finish.

The stadium, filled to capacity, erupted as the winning runs were struck with two balls to spare. The player of the match, a young all-rounder playing in his first major final, credited the team's fielding coach for a training regime that focused heavily on pressure situations. The victory marks the team's first tournament win in six years and is expected to boost interest in the domestic league ahead of next season.`,
    image: 'cricket',
    tags: ['cricket', 'tournament', 'final', 'sports'],
  },
  {
    id: 'business-1',
    title: 'Stock Market Rallies as Inflation Cools',
    category: 'Business',
    source: 'BizToday',
    author: 'Lena Osei',
    date: '2026-09-21',
    readingTime: 5,
    description: 'Equity markets posted their strongest week in months after inflation data came in below expectations.',
    content: `Stock markets rallied sharply this week after new inflation figures came in below analyst expectations, easing concerns that the central bank would need to keep interest rates elevated for longer. The benchmark index posted its strongest weekly gain in months, led by gains in consumer goods and technology shares.

Economists said the cooling inflation trend, driven partly by falling energy prices, gives the central bank more room to consider rate cuts later in the year. Bond yields fell in tandem with the improved outlook. Still, some analysts cautioned that a single month of data is not enough to declare victory over inflation, noting that services inflation remains sticky in several sectors.

Retail investors have returned to the market in growing numbers, according to brokerage data, reversing months of net outflows from equity funds.`,
    image: 'market',
    tags: ['stock market', 'inflation', 'interest rates', 'economy'],
  },
  {
    id: 'health-1',
    title: 'New Vaccine Shows Promise in Hospital Trials',
    category: 'Health',
    source: 'HealthNow',
    author: 'Dr. Farah Iqbal',
    date: '2026-09-17',
    readingTime: 4,
    description: 'Early hospital trial results suggest strong efficacy for a newly developed vaccine candidate.',
    content: `A newly developed vaccine has shown strong efficacy in early hospital trials, according to results released this week. Researchers tracked outcomes across several hospital sites and found a significant reduction in severe illness among vaccinated participants compared to the control group.

The trial's lead investigator said the results were encouraging but stressed that larger, longer-term studies are still needed before regulatory approval can be sought. Health officials welcomed the news, noting that a successful vaccine could ease pressure on hospital systems during peak seasons. The manufacturer said it is preparing to begin a larger multi-country trial by early next year, pending regulatory clearance.

Public health experts also emphasized the continued importance of existing vaccination programs while the new candidate completes testing.`,
    image: 'vaccine',
    tags: ['vaccine', 'hospital trials', 'health', 'medicine'],
  },
  {
    id: 'politics-1',
    title: 'Parliament Debates New Election Law',
    category: 'Politics',
    source: 'PolicyWatch',
    author: 'Ramesh Chandra',
    date: '2026-09-19',
    readingTime: 6,
    description: 'Lawmakers clashed over proposed changes to voter registration and campaign finance rules.',
    content: `Lawmakers engaged in a lengthy debate this week over a proposed election law that would change voter registration procedures and tighten campaign finance disclosure requirements. Supporters of the bill argue it will modernize outdated registration systems and increase transparency around political donations.

Opposition lawmakers raised concerns that some provisions could make registration more difficult for certain groups of voters, and called for further committee review before a final vote. The bill's sponsors said they are open to amendments but want to see the law in place well ahead of the next election cycle.

Civil society groups have submitted mixed testimony, with some praising the transparency measures and others warning about implementation timelines. A final vote is expected within the coming weeks.`,
    image: 'parliament',
    tags: ['election', 'law', 'parliament', 'politics', 'voting'],
  },
  {
    id: 'tech-2',
    title: 'Tech Company Unveils Robot for Warehouses',
    category: 'Technology',
    source: 'TechDaily',
    author: 'Marcus Lin',
    date: '2026-09-22',
    readingTime: 4,
    description: 'The new autonomous robot is designed to handle sorting and heavy lifting in large distribution centers.',
    content: `A major logistics technology company has unveiled a new autonomous robot designed for warehouse sorting and heavy lifting tasks. The robot uses a combination of computer vision and machine learning to identify packages, plan routes through crowded aisles, and coordinate with other robots on the floor.

Company executives said the robot is aimed at distribution centers struggling with labor shortages during peak shopping seasons. Early pilot deployments reportedly reduced sorting time by nearly a third at partner facilities. Labor advocates have raised questions about the long-term impact of warehouse automation on jobs, while the company maintains that the robots are meant to handle repetitive tasks rather than replace warehouse staff entirely.

The robot is expected to enter wider production next year, with the company targeting large e-commerce fulfillment operations first.`,
    image: 'robot',
    tags: ['robotics', 'warehouse', 'automation', 'technology', 'artificial intelligence'],
  },
  {
    id: 'business-2',
    title: 'Central Bank Holds Interest Rates Steady',
    category: 'Business',
    source: 'BizToday',
    author: 'Lena Osei',
    date: '2026-09-15',
    readingTime: 4,
    description: 'Policymakers opted for caution, keeping rates unchanged while signaling a possible cut later this year.',
    content: `The central bank kept its benchmark interest rate unchanged this week, opting for caution even as recent data showed signs of cooling inflation. In a statement, policymakers said they want to see a sustained trend before committing to a rate cut, citing lingering uncertainty in labor markets.

The decision was widely expected by economists, though the accompanying statement was read by markets as slightly more dovish than the previous meeting. Several analysts now expect the first rate cut of the cycle to arrive within the next two policy meetings if inflation data continues to soften.

Business groups welcomed the signal of a possible cut, saying lower borrowing costs would help smaller companies facing tight credit conditions.`,
    image: 'bank',
    tags: ['interest rates', 'central bank', 'economy', 'inflation'],
  },
  {
    id: 'sports-2',
    title: 'Football League Announces Expanded Tournament Format',
    category: 'Sports',
    source: 'SportsWire',
    author: 'Diego Ferreira',
    date: '2026-09-14',
    readingTime: 3,
    description: 'The league will add more teams and a new group stage starting next season.',
    content: `The football league announced a major expansion of its flagship tournament, adding eight new teams and introducing a revised group stage format starting next season. League officials said the changes are designed to increase competitive balance and give more clubs a realistic path to the knockout rounds.

The expanded format will increase the number of matches played, a move that has drawn mixed reactions from players' associations concerned about fixture congestion. Broadcasters, meanwhile, welcomed the change, citing increased commercial value from additional high-profile matches.

Clubs have until the end of the year to qualify under the new criteria, with several mid-table teams from smaller leagues seen as the biggest beneficiaries of the expanded format.`,
    image: 'football',
    tags: ['football', 'tournament', 'league', 'sports'],
  },
  {
    id: 'health-2',
    title: 'Study Links Sleep Patterns to Long-Term Heart Health',
    category: 'Health',
    source: 'HealthNow',
    author: 'Dr. Farah Iqbal',
    date: '2026-09-12',
    readingTime: 5,
    description: 'Researchers tracked participants for a decade and found consistent sleep timing correlated with lower cardiovascular risk.',
    content: `A decade-long study has found that consistent sleep timing, rather than total sleep duration alone, is strongly associated with lower long-term cardiovascular risk. Researchers followed several thousand participants, tracking sleep patterns alongside standard heart health markers.

Participants who kept irregular sleep schedules, even if they slept a similar total number of hours, showed higher rates of hypertension and other cardiovascular issues over the study period. The researchers suggest that circadian disruption may play a larger role in heart health than previously understood.

The study's authors caution that the findings are observational and do not prove causation, but they say the results support existing guidance encouraging consistent sleep and wake times as part of general cardiovascular health.`,
    image: 'sleep',
    tags: ['health', 'sleep', 'heart', 'study', 'cardiovascular'],
  },
  {
    id: 'politics-2',
    title: 'City Council Approves New Public Transit Budget',
    category: 'Politics',
    source: 'PolicyWatch',
    author: 'Sofia Alvarez',
    date: '2026-09-10',
    readingTime: 4,
    description: 'The council voted to expand bus routes and fund a long-delayed light rail extension.',
    content: `The city council approved a new transit budget that expands bus service coverage and allocates funding to a long-delayed light rail extension. Officials said the plan aims to reduce commute times in fast-growing suburbs that currently lack reliable public transit options.

Supporters of the budget say it addresses years of underinvestment in transit infrastructure, while some council members expressed concern about the funding mechanism, which relies partly on a new vehicle registration fee. The transit authority said construction on the light rail extension could begin within eighteen months if the budget holds through the next fiscal cycle.

Community groups that have long advocated for expanded transit access called the vote a significant win, though they urged the council to prioritize routes serving lower-income neighborhoods first.`,
    image: 'transit',
    tags: ['transit', 'city council', 'budget', 'politics', 'infrastructure'],
  },
  {
    id: 'tech-3',
    title: 'Researchers Develop More Efficient Battery Recycling Method',
    category: 'Technology',
    source: 'TechDaily',
    author: 'Marcus Lin',
    date: '2026-09-08',
    readingTime: 4,
    description: 'A university lab says the new process recovers more lithium at a lower environmental cost.',
    content: `A university research lab has developed a new battery recycling process that the team says recovers significantly more lithium than existing methods while using less energy and fewer harsh chemicals. The technique separates battery materials using a low-temperature process rather than the high-heat smelting common in industrial recycling today.

The researchers say the approach could make recycling more economically viable for electric vehicle battery packs as they reach end of life over the next decade. Several battery manufacturers have expressed interest in licensing the technology for pilot facilities.

Environmental groups welcomed the development, noting that recycling capacity has lagged behind the rapid growth in electric vehicle battery production, raising concerns about future material shortages and disposal challenges.`,
    image: 'battery',
    tags: ['battery', 'recycling', 'technology', 'electric vehicles', 'environment'],
  },
  {
    id: 'business-3',
    title: 'Retailers Report Strong Holiday Season Ahead of Forecasts',
    category: 'Business',
    source: 'BizToday',
    author: 'Lena Osei',
    date: '2026-09-05',
    readingTime: 4,
    description: 'Early sales data suggests consumer spending is holding up better than analysts predicted.',
    content: `Major retailers reported stronger-than-expected sales heading into the holiday season, with early data suggesting consumer spending is holding up despite months of cautious forecasts from analysts. Several large chains raised their full-year guidance following the results.

Analysts had expected spending to soften given persistently high borrowing costs, but resilient job growth appears to be supporting household budgets. Online sales in particular outperformed expectations, with same-day delivery options cited as a key driver of growth.

Retail executives cautioned that the crucial final weeks of the season will determine whether the early strength holds, noting that consumer sentiment can shift quickly in response to economic news.`,
    image: 'retail',
    tags: ['retail', 'holiday season', 'consumer spending', 'business'],
  },
  {
    id: 'sports-3',
    title: 'Young Swimmer Breaks National Record at Championships',
    category: 'Sports',
    source: 'SportsWire',
    author: 'Arjun Mehta',
    date: '2026-09-03',
    readingTime: 3,
    description: 'The 17-year-old shattered a decade-old national record in the 200-meter freestyle.',
    content: `A 17-year-old swimmer broke a national record that had stood for over a decade, clocking a winning time in the 200-meter freestyle at the national championships. Coaches described the swim as one of the most dominant performances seen at the meet in years.

The swimmer, who only began competing at the national level two years ago, said the result was the product of a training block focused heavily on technique refinement rather than pure volume. National team selectors said the performance puts the swimmer firmly in contention for an international qualifying spot next season.

The record-breaking swim capped a strong week for the home team at the championships, which also saw two other national records fall in relay events.`,
    image: 'swim',
    tags: ['swimming', 'championship', 'record', 'sports'],
  },
  {
    id: 'health-3',
    title: 'Health Officials Urge Caution as Flu Season Approaches',
    category: 'Health',
    source: 'HealthNow',
    author: 'Dr. Farah Iqbal',
    date: '2026-09-02',
    readingTime: 3,
    description: 'Officials are encouraging early vaccination as forecasting models predict an active flu season.',
    content: `Health officials are urging residents to get vaccinated early as forecasting models point to an active flu season this year. Surveillance data from the southern hemisphere, often used to anticipate northern hemisphere flu trends, showed higher-than-average case counts during its recent flu season.

Officials said clinics and pharmacies are stocked and ready to administer vaccines, and encouraged high-risk groups, including older adults and young children, to prioritize getting vaccinated in the coming weeks. Hospitals have also reviewed surge capacity plans in preparation for a potentially busier winter.

Public health messaging this year has also emphasized basic precautions such as handwashing and staying home when symptomatic, alongside the vaccination push.`,
    image: 'flu',
    tags: ['flu', 'vaccination', 'health', 'season'],
  },
  {
    id: 'politics-3',
    title: 'Trade Negotiators Reach Preliminary Agreement on Tariffs',
    category: 'Politics',
    source: 'PolicyWatch',
    author: 'Ramesh Chandra',
    date: '2026-08-30',
    readingTime: 5,
    description: 'The preliminary deal would reduce tariffs on a range of manufactured goods over three years.',
    content: `Trade negotiators from both countries announced a preliminary agreement that would gradually reduce tariffs on a range of manufactured goods over the next three years. Officials described the deal as a significant step toward resolving a trade dispute that has weighed on manufacturers on both sides.

The agreement still requires formal ratification, and both sides said several technical details remain to be finalized before a signing ceremony can be scheduled. Industry groups representing manufacturers welcomed the news, saying reduced tariffs would lower input costs for a range of products.

Some domestic industry groups expressed concern about increased competition from cheaper imports, urging negotiators to include stronger safeguard provisions in the final text of the agreement.`,
    image: 'trade',
    tags: ['trade', 'tariffs', 'agreement', 'politics', 'economy'],
  },
  {
    id: 'tech-4',
    title: 'Software Company Patches Critical Security Flaw',
    category: 'Technology',
    source: 'TechDaily',
    author: 'Priya Nandan',
    date: '2026-08-28',
    readingTime: 3,
    description: 'The company urged customers to update immediately after researchers disclosed the vulnerability.',
    content: `A major software company released an emergency patch this week after security researchers disclosed a critical vulnerability affecting a widely used enterprise product. The company urged all customers to update immediately, saying the flaw could allow attackers to gain unauthorized access to affected systems.

Security researchers who discovered the flaw said they found no evidence it had been exploited before disclosure, but warned that attackers often move quickly once a vulnerability becomes public knowledge. The company said it is working with major cloud providers to help push the patch to affected systems as quickly as possible.

Cybersecurity experts recommended that organizations review their update logs and apply the patch as a top priority given the severity rating assigned to the vulnerability.`,
    image: 'security',
    tags: ['security', 'software', 'vulnerability', 'technology'],
  },
  {
    id: 'business-4',
    title: 'Startup Founders Turn to Alternative Funding as VC Slows',
    category: 'Business',
    source: 'BizToday',
    author: 'Lena Osei',
    date: '2026-08-25',
    readingTime: 4,
    description: 'With venture capital harder to raise, more founders are exploring revenue-based financing.',
    content: `With venture capital harder to raise than in previous years, a growing number of startup founders are turning to alternative financing structures such as revenue-based financing and smaller angel rounds. Founders say these options come with fewer strings attached than traditional equity funding, though they typically provide smaller amounts of capital.

Investors who specialize in these alternative structures say demand has grown noticeably over the past year as founders look to extend their runway without diluting ownership at unfavorable valuations. Some venture capital firms have responded by introducing more flexible deal terms of their own.

Analysts note that the shift reflects broader caution in the funding environment, with investors prioritizing startups that can demonstrate a clear path to profitability over rapid, unprofitable growth.`,
    image: 'funding',
    tags: ['startup', 'funding', 'venture capital', 'business'],
  },
]

export default articles

export const CATEGORIES = ['Technology', 'Sports', 'Business', 'Health', 'Politics']

export const CATEGORY_META = {
  Technology: { description: 'Chips, software, robotics and the tools reshaping how we build.' },
  Sports: { description: 'Results, records and the moments that define a season.' },
  Business: { description: 'Markets, companies and the economics behind the headlines.' },
  Health: { description: 'Research, public health and the science of staying well.' },
  Politics: { description: 'Policy, elections and the decisions that shape public life.' },
}
