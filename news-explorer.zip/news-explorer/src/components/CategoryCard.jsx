import { Link } from 'react-router-dom'
import { FiCpu, FiActivity, FiTrendingUp, FiHeart, FiFlag, FiArrowRight } from 'react-icons/fi'
import './CategoryCard.css'

const ICONS = {
  Technology: FiCpu,
  Sports: FiActivity,
  Business: FiTrendingUp,
  Health: FiHeart,
  Politics: FiFlag,
}

export default function CategoryCard({ category }) {
  const Icon = ICONS[category.name] || FiCpu

  return (
    <Link to={`/categories/${category.name.toLowerCase()}`} className="category-card">
      <div className={`category-card__icon article-image--${category.name}`}>
        <Icon />
      </div>
      <div className="category-card__body">
        <h3>{category.name}</h3>
        <p>{category.description}</p>
        <span className="category-card__count">{category.count} articles</span>
      </div>
      <FiArrowRight className="category-card__arrow" />
    </Link>
  )
}
