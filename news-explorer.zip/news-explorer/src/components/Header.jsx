import { useState } from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import { FiSearch, FiMenu, FiX, FiBookmark } from 'react-icons/fi'
import { useSavedArticles } from '../hooks/useSavedArticles.js'
import './Header.css'

const NAV_LINKS = [
  { to: '/', label: 'Home', end: true },
  { to: '/explore', label: 'Explore' },
  { to: '/categories', label: 'Categories' },
  { to: '/recommendations', label: 'Recommendations' },
  { to: '/how-it-works', label: 'How It Works' },
]

export default function Header() {
  const [menuOpen, setMenuOpen] = useState(false)
  const { savedIds } = useSavedArticles()
  const navigate = useNavigate()

  const goToSearch = () => {
    setMenuOpen(false)
    navigate('/explore')
  }

  return (
    <header className="site-header">
      <div className="container site-header__inner">
        <NavLink to="/" className="brand" onClick={() => setMenuOpen(false)}>
          <span className="brand__mark">N</span>
          <span className="brand__name">News Explorer</span>
        </NavLink>

        <nav className={`main-nav ${menuOpen ? 'main-nav--open' : ''}`}>
          {NAV_LINKS.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              end={link.end}
              className={({ isActive }) => `main-nav__link ${isActive ? 'main-nav__link--active' : ''}`}
              onClick={() => setMenuOpen(false)}
            >
              {link.label}
            </NavLink>
          ))}
          <NavLink
            to="/saved"
            className={({ isActive }) => `main-nav__link main-nav__link--saved ${isActive ? 'main-nav__link--active' : ''}`}
            onClick={() => setMenuOpen(false)}
          >
            <FiBookmark />
            Saved
            {savedIds.length > 0 && <span className="saved-count">{savedIds.length}</span>}
          </NavLink>
        </nav>

        <div className="site-header__actions">
          <button className="icon-btn" aria-label="Search" onClick={goToSearch}>
            <FiSearch />
          </button>
          <button
            className="icon-btn menu-toggle"
            aria-label={menuOpen ? 'Close menu' : 'Open menu'}
            onClick={() => setMenuOpen((open) => !open)}
          >
            {menuOpen ? <FiX /> : <FiMenu />}
          </button>
        </div>
      </div>
    </header>
  )
}
