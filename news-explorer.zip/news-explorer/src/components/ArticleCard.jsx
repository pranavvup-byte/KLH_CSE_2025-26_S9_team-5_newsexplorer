import { Link } from 'react-router-dom'
import { FiBookmark, FiClock } from 'react-icons/fi'
import ArticleImage from './ArticleImage.jsx'
import { useSavedArticles } from '../hooks/useSavedArticles.js'
import { showToast } from '../hooks/useToast.js'
import './ArticleCard.css'

function formatDate(dateStr) {
  return new Date(dateStr).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
}

export default function ArticleCard({ article, score, onSaveToggle }) {
  const { isSaved, toggleSaved } = useSavedArticles()
  const saved = isSaved(article.id)

  const handleSave = (event) => {
    event.preventDefault()
    event.stopPropagation()
    const nowSaved = toggleSaved(article.id)
    showToast(nowSaved ? 'Article saved' : 'Removed from saved')
    onSaveToggle?.(article, nowSaved)
  }

  return (
    <Link to={`/article/${article.id}`} className="article-card">
      <ArticleImage category={article.category} />
      <div className="article-card__body">
        <div className="article-card__meta">
          <span className={`category-pill ${article.category}`}>{article.category}</span>
          <span className="article-card__source">{article.source}</span>
        </div>

        <h3 className="article-card__title">{article.title}</h3>
        <p className="article-card__desc">{article.description}</p>

        <div className="article-card__footer">
          <span className="article-card__date">{formatDate(article.date)}</span>
          <span className="article-card__dot">·</span>
          <span className="article-card__reading">
            <FiClock /> {article.readingTime} min read
          </span>
          {typeof score === 'number' && score > 0 && (
            <span className="article-card__score" title="Relevance score from TF-IDF + cosine similarity">
              {Math.round(score * 100)}% match
            </span>
          )}
        </div>
      </div>

      <button
        className={`article-card__save ${saved ? 'article-card__save--active' : ''}`}
        onClick={handleSave}
        aria-label={saved ? 'Remove from saved' : 'Save article'}
        aria-pressed={saved}
      >
        <FiBookmark />
      </button>
    </Link>
  )
}
