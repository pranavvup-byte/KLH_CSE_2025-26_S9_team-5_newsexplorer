import { FiCheckCircle } from 'react-icons/fi'

export default function Toast({ message }) {
  if (!message) return null
  return (
    <div className="toast" role="status">
      <FiCheckCircle />
      {message}
    </div>
  )
}
