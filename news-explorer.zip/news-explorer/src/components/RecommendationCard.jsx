import { Link } from 'react-router-dom'
import ArticleImage from './ArticleImage.jsx'
import './RecommendationCard.css'

export default function RecommendationCard({ article, score }) {
  return (
    <Link to={`/article/${article.id}`} className="rec-card">
      <ArticleImage category={article.category} size="sm" />
      <div className="rec-card__body">
        <span className={`category-pill ${article.category}`}>{article.category}</span>
        <h4>{article.title}</h4>
        <span className="rec-card__source">{article.source}</span>
      </div>
      {typeof score === 'number' && score > 0 && (
        <span className="rec-card__score">{Math.round(score * 100)}%</span>
      )}
    </Link>
  )
}
