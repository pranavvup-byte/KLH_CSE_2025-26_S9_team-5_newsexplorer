import { useEffect, useState } from 'react'
import ArticleGrid from '../components/ArticleGrid.jsx'
import { getRecommendationsForInterests, CATEGORIES } from '../services/newsService.js'
import './Recommendations.css'

const PIPELINE_STEPS = [
  'Article content',
  'TF-IDF representation',
  'Cosine similarity',
  'Similar articles',
  'Personalized recommendations',
]

export default function Recommendations() {
  const [interests, setInterests] = useState(['Technology', 'Business'])
  const [recommended, setRecommended] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setLoading(true)
    getRecommendationsForInterests(interests).then((articles) => {
      setRecommended(articles)
      setLoading(false)
    })
  }, [interests])

  const toggleInterest = (category) => {
    setInterests((current) =>
      current.includes(category) ? current.filter((c) => c !== category) : [...current, category],
    )
  }

  return (
    <div className="page container recommendations-page">
      <div className="page-heading">
        <h1>Recommended for you</h1>
        <p>Stories selected based on your interests.</p>
      </div>

      <div className="interest-chips">
        {CATEGORIES.map((category) => (
          <button
            key={category}
            className={`chip ${interests.includes(category) ? 'active' : ''}`}
            onClick={() => toggleInterest(category)}
          >
            {category}
          </button>
        ))}
      </div>

      <ArticleGrid results={recommended.map((article) => ({ article }))} loading={loading} />

      <section className="pipeline-section">
        <h2>How recommendations work</h2>
        <p className="pipeline-section__intro">
          Every article is converted into a weighted keyword profile. Recommendations come from comparing those
          profiles rather than simple category matching.
        </p>
        <div className="pipeline">
          {PIPELINE_STEPS.map((step, index) => (
            <div className="pipeline__step" key={step}>
              <div className="pipeline__node">{index + 1}</div>
              <span>{step}</span>
              {index < PIPELINE_STEPS.length - 1 && <div className="pipeline__connector" aria-hidden="true" />}
            </div>
          ))}
        </div>
      </section>
    </div>
  )
}
