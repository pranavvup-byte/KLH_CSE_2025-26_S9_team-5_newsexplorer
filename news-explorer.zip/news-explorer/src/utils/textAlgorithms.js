// ---------------------------------------------------------------------------
// textAlgorithms.js
//
// This module is a small, real (not fake) implementation of the same ideas
// that power the Java backend: tokenization, an inverted index, TF-IDF
// vectors, cosine similarity, Damerau-Levenshtein fuzzy matching, and a KMP
// exact-phrase search. It runs entirely in the browser so the frontend has
// something genuine to demonstrate even before a backend API is wired up.
// ---------------------------------------------------------------------------

const STOPWORDS = new Set([
  'a', 'an', 'the', 'and', 'or', 'but', 'if', 'then', 'is', 'are', 'was',
  'were', 'be', 'been', 'being', 'to', 'of', 'in', 'on', 'for', 'with',
  'as', 'by', 'at', 'from', 'that', 'this', 'it', 'its', 'into', 'over',
  'after', 'before', 'about', 'than', 'their', 'they', 'has', 'have',
  'had', 'will', 'would', 'could', 'should', 'can', 'up', 'down', 'out',
  'not', 'no', 'so', 'do', 'does', 'did', 'more', 'most', 'also',
])

/** Lowercase, strip punctuation, split on whitespace, drop stopwords. */
export function tokenize(text) {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter((word) => word.length > 1 && !STOPWORDS.has(word))
}

/** Build an inverted index: term -> Set of article ids containing it. */
export function buildInvertedIndex(articles) {
  const index = new Map()
  for (const article of articles) {
    const terms = new Set(tokenize(`${article.title} ${article.description} ${article.content}`))
    for (const term of terms) {
      if (!index.has(term)) index.set(term, new Set())
      index.get(term).add(article.id)
    }
  }
  return index
}

function termFrequencies(tokens) {
  const tf = new Map()
  for (const token of tokens) tf.set(token, (tf.get(token) || 0) + 1)
  return tf
}

/**
 * Build a TF-IDF vector (as a plain object) for every article, plus the
 * document-frequency map needed to score a fresh query against them.
 */
export function buildTfIdfModel(articles) {
  const docTokens = new Map()
  const df = new Map()

  for (const article of articles) {
    const tokens = tokenize(`${article.title} ${article.title} ${article.description} ${article.content}`)
    docTokens.set(article.id, tokens)
    const seen = new Set(tokens)
    for (const term of seen) df.set(term, (df.get(term) || 0) + 1)
  }

  const N = articles.length
  const vectors = new Map()

  for (const [id, tokens] of docTokens.entries()) {
    const tf = termFrequencies(tokens)
    const vector = new Map()
    for (const [term, count] of tf.entries()) {
      const idf = Math.log((N + 1) / (df.get(term) + 1)) + 1
      vector.set(term, (count / tokens.length) * idf)
    }
    vectors.set(id, vector)
  }

  return { vectors, df, N }
}

function vectorizeQuery(query, model) {
  const tokens = tokenize(query)
  const tf = termFrequencies(tokens)
  const vector = new Map()
  for (const [term, count] of tf.entries()) {
    const idf = Math.log((model.N + 1) / ((model.df.get(term) || 0) + 1)) + 1
    vector.set(term, (count / tokens.length) * idf)
  }
  return vector
}

/** Cosine similarity between two sparse vectors represented as Maps. */
export function cosineSimilarity(vecA, vecB) {
  let dot = 0
  let magA = 0
  let magB = 0
  for (const value of vecA.values()) magA += value * value
  for (const value of vecB.values()) magB += value * value
  const [smaller, larger] = vecA.size < vecB.size ? [vecA, vecB] : [vecB, vecA]
  for (const [term, value] of smaller.entries()) {
    if (larger.has(term)) dot += value * larger.get(term)
  }
  if (magA === 0 || magB === 0) return 0
  return dot / (Math.sqrt(magA) * Math.sqrt(magB))
}

/** Rank every article against a free-text query using TF-IDF + cosine similarity. */
export function rankByQuery(query, articles, model) {
  const queryVector = vectorizeQuery(query, model)
  return articles
    .map((article) => ({
      article,
      score: cosineSimilarity(queryVector, model.vectors.get(article.id)),
    }))
    .filter((entry) => entry.score > 0)
    .sort((a, b) => b.score - a.score)
}

/** Rank every other article's similarity to one article (for recommendations). */
export function rankSimilarArticles(articleId, articles, model, topN = 4) {
  const baseVector = model.vectors.get(articleId)
  if (!baseVector) return []
  return articles
    .filter((a) => a.id !== articleId)
    .map((article) => ({
      article,
      score: cosineSimilarity(baseVector, model.vectors.get(article.id)),
    }))
    .sort((a, b) => b.score - a.score)
    .slice(0, topN)
}

/**
 * Damerau-Levenshtein edit distance: counts insertions, deletions,
 * substitutions, and adjacent transpositions between two strings.
 */
export function damerauLevenshtein(a, b) {
  const al = a.length
  const bl = b.length
  const d = Array.from({ length: al + 1 }, () => new Array(bl + 1).fill(0))

  for (let i = 0; i <= al; i++) d[i][0] = i
  for (let j = 0; j <= bl; j++) d[0][j] = j

  for (let i = 1; i <= al; i++) {
    for (let j = 1; j <= bl; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1
      d[i][j] = Math.min(
        d[i - 1][j] + 1,
        d[i][j - 1] + 1,
        d[i - 1][j - 1] + cost,
      )
      if (
        i > 1 && j > 1 &&
        a[i - 1] === b[j - 2] &&
        a[i - 2] === b[j - 1]
      ) {
        d[i][j] = Math.min(d[i][j], d[i - 2][j - 2] + cost)
      }
    }
  }
  return d[al][bl]
}

/**
 * Given a mistyped query and a vocabulary (built from the corpus), find the
 * closest known term(s) within an edit-distance threshold — this is the
 * "Did you mean?" feature.
 */
export function getFuzzySuggestion(query, vocabulary) {
  const words = query.toLowerCase().trim().split(/\s+/)
  let changed = false
  const corrected = words.map((word) => {
    if (vocabulary.has(word)) return word
    let best = null
    let bestDistance = Infinity
    const threshold = word.length <= 4 ? 1 : 2
    for (const term of vocabulary) {
      if (Math.abs(term.length - word.length) > threshold) continue
      const distance = damerauLevenshtein(word, term)
      if (distance < bestDistance) {
        bestDistance = distance
        best = term
      }
    }
    if (best && bestDistance > 0 && bestDistance <= threshold) {
      changed = true
      return best
    }
    return word
  })
  return changed ? corrected.join(' ') : null
}

export function buildVocabulary(articles) {
  const vocabulary = new Set()
  for (const article of articles) {
    for (const token of tokenize(`${article.title} ${article.description} ${article.content}`)) {
      vocabulary.add(token)
    }
  }
  return vocabulary
}

/** Knuth-Morris-Pratt exact phrase search. Returns true if `pattern` occurs in `text`. */
export function kmpSearch(text, pattern) {
  if (pattern.length === 0) return false
  const lps = new Array(pattern.length).fill(0)
  let len = 0
  let i = 1
  while (i < pattern.length) {
    if (pattern[i] === pattern[len]) {
      len++
      lps[i] = len
      i++
    } else if (len !== 0) {
      len = lps[len - 1]
    } else {
      lps[i] = 0
      i++
    }
  }

  let ti = 0
  let pi = 0
  while (ti < text.length) {
    if (text[ti] === pattern[pi]) {
      ti++
      pi++
      if (pi === pattern.length) return true
    } else if (pi !== 0) {
      pi = lps[pi - 1]
    } else {
      ti++
    }
  }
  return false
}

/** Exact phrase search across the corpus using KMP, case-insensitive. */
export function phraseSearch(phrase, articles) {
  const needle = phrase.toLowerCase().trim()
  return articles.filter((article) =>
    kmpSearch(`${article.title} ${article.description} ${article.content}`.toLowerCase(), needle),
  )
}
