import { FiSearch, FiX } from 'react-icons/fi'
import './SearchBar.css'

export default function SearchBar({
  value,
  onChange,
  onSubmit,
  placeholder = 'Search news, topics or keywords…',
  size = 'md',
  showExactPhrase = false,
  exactPhrase = false,
  onToggleExactPhrase,
}) {
  const handleSubmit = (event) => {
    event.preventDefault()
    onSubmit?.(value)
  }

  return (
    <form className={`search-bar search-bar--${size}`} onSubmit={handleSubmit} role="search">
      <div className="search-bar__field">
        <FiSearch className="search-bar__icon" aria-hidden="true" />
        <input
          type="text"
          value={value}
          onChange={(event) => onChange(event.target.value)}
          placeholder={placeholder}
          aria-label="Search news"
        />
        {value && (
          <button
            type="button"
            className="search-bar__clear"
            aria-label="Clear search"
            onClick={() => onChange('')}
          >
            <FiX />
          </button>
        )}
        <button type="submit" className="btn btn-primary search-bar__submit">
          Search
        </button>
      </div>

      {showExactPhrase && (
        <label className="search-bar__toggle">
          <input
            type="checkbox"
            checked={exactPhrase}
            onChange={(event) => onToggleExactPhrase?.(event.target.checked)}
          />
          Match exact phrase
        </label>
      )}
    </form>
  )
}
