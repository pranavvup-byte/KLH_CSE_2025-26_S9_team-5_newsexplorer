import ArticleCard from './ArticleCard.jsx'
import SkeletonCard from './SkeletonCard.jsx'
import EmptyState from './EmptyState.jsx'
import './ArticleGrid.css'

export default function ArticleGrid({ results, loading, skeletonCount = 6, emptyState, onSaveToggle }) {
  if (loading) {
    return (
      <div className="article-grid">
        {Array.from({ length: skeletonCount }).map((_, index) => (
          <SkeletonCard key={index} />
        ))}
      </div>
    )
  }

  if (!results || results.length === 0) {
    return emptyState || <EmptyState title="No articles found" description="Try a different search term or filter." />
  }

  return (
    <div className="article-grid">
      {results.map((entry) => {
        const article = entry.article || entry
        const score = entry.score
        return <ArticleCard key={article.id} article={article} score={score} onSaveToggle={onSaveToggle} />
      })}
    </div>
  )
}
