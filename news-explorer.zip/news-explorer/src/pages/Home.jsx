import { useEffect, useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { FiCpu, FiActivity, FiTrendingUp, FiHeart, FiFlag, FiArrowRight } from 'react-icons/fi'
import SearchBar from '../components/SearchBar.jsx'
import ArticleGrid from '../components/ArticleGrid.jsx'
import { getLatestArticles } from '../services/newsService.js'
import './Home.css'

const TOPICS = [
  { name: 'Technology', icon: FiCpu },
  { name: 'Sports', icon: FiActivity },
  { name: 'Business', icon: FiTrendingUp },
  { name: 'Health', icon: FiHeart },
  { name: 'Politics', icon: FiFlag },
]

export default function Home() {
  const [query, setQuery] = useState('')
  const [latest, setLatest] = useState([])
  const [loading, setLoading] = useState(true)
  const navigate = useNavigate()

  useEffect(() => {
    let active = true
    getLatestArticles(6).then((articles) => {
      if (active) {
        setLatest(articles)
        setLoading(false)
      }
    })
    return () => {
      active = false
    }
  }, [])

  const handleSearch = (value) => {
    if (!value.trim()) return
    navigate(`/explore?q=${encodeURIComponent(value.trim())}`)
  }

  const handleTopicClick = (topic) => {
    navigate(`/explore?category=${encodeURIComponent(topic)}`)
  }

  return (
    <div className="page">
      <section className="hero">
        <div className="container hero__inner">
          <h1 className="hero__title">Explore the news that matters.</h1>
          <p className="hero__subtitle">
            Search across daily publications, follow the topics you care about, and let similarity-based
            recommendations surface what to read next.
          </p>
          <div className="hero__search">
            <SearchBar value={query} onChange={setQuery} onSubmit={handleSearch} size="lg" />
          </div>
        </div>
      </section>

      <section className="container section">
        <h2 className="section__heading">Trending topics</h2>
        <div className="topic-row">
          {TOPICS.map(({ name, icon: Icon }) => (
            <button key={name} className="topic-card" onClick={() => handleTopicClick(name)}>
              <Icon className={`topic-card__icon topic-card__icon--${name}`} />
              <span>{name}</span>
            </button>
          ))}
        </div>
      </section>

      <section className="container section">
        <div className="section__header">
          <h2 className="section__heading">Latest news</h2>
          <Link to="/explore" className="section__link">
            View all <FiArrowRight />
          </Link>
        </div>
        <ArticleGrid results={latest.map((article) => ({ article }))} loading={loading} />
      </section>
    </div>
  )
}
