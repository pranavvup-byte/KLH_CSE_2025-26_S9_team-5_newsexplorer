import { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { FiArrowLeft } from 'react-icons/fi'
import ArticleGrid from '../components/ArticleGrid.jsx'
import ArticleCard from '../components/ArticleCard.jsx'
import { getArticlesByCategory, CATEGORIES } from '../services/newsService.js'
import './CategoryDetail.css'

export default function CategoryDetail() {
  const { name } = useParams()
  const category = CATEGORIES.find((c) => c.toLowerCase() === name.toLowerCase()) || name
  const [articles, setArticles] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setLoading(true)
    getArticlesByCategory(category).then((data) => {
      setArticles(data)
      setLoading(false)
    })
  }, [category])

  const [featured, ...rest] = articles

  return (
    <div className="page container category-detail">
      <Link to="/categories" className="back-link">
        <FiArrowLeft /> All categories
      </Link>

      <div className="page-heading">
        <span className={`category-pill ${category}`}>{category}</span>
        <h1>{category}</h1>
      </div>

      {loading ? (
        <ArticleGrid results={[]} loading skeletonCount={4} />
      ) : (
        <>
          {featured && (
            <div className="category-featured">
              <ArticleCard article={featured} />
            </div>
          )}
          <ArticleGrid results={rest.map((article) => ({ article }))} loading={false} />
        </>
      )}
    </div>
  )
}
