import './FilterBar.css'

const CATEGORY_OPTIONS = ['All', 'Technology', 'Sports', 'Business', 'Health', 'Politics', 'General']
const SORT_OPTIONS = [
  { value: 'relevance', label: 'Relevance' },
  { value: 'latest', label: 'Latest' },
  { value: 'oldest', label: 'Oldest' },
]

export default function FilterBar({ category, onCategoryChange, sortBy, onSortChange }) {
  return (
    <div className="filter-bar">
      <div className="filter-bar__chips">
        {CATEGORY_OPTIONS.map((option) => (
          <button
            key={option}
            className={`chip ${category === option ? 'active' : ''}`}
            onClick={() => onCategoryChange(option)}
          >
            {option}
          </button>
        ))}
      </div>

      <div className="filter-bar__sort">
        <label htmlFor="sort-select">Sort by</label>
        <select id="sort-select" value={sortBy} onChange={(event) => onSortChange(event.target.value)}>
          {SORT_OPTIONS.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
      </div>
    </div>
  )
}
