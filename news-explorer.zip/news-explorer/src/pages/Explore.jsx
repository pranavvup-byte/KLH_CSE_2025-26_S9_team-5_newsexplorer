import { useCallback, useEffect, useRef, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import SearchBar from '../components/SearchBar.jsx'
import FilterBar from '../components/FilterBar.jsx'
import ArticleGrid from '../components/ArticleGrid.jsx'
import EmptyState from '../components/EmptyState.jsx'
import { searchArticles, getFuzzySuggestions } from '../services/newsService.js'
import { FiSearch } from 'react-icons/fi'
import './Explore.css'

export default function Explore() {
  const [searchParams, setSearchParams] = useSearchParams()
  const initialQuery = searchParams.get('q') || ''
  const initialCategory = searchParams.get('category') || 'All'

  const [query, setQuery] = useState(initialQuery)
  const [activeQuery, setActiveQuery] = useState(initialQuery)
  const [category, setCategory] = useState(initialCategory)
  const [sortBy, setSortBy] = useState('relevance')
  const [exactPhrase, setExactPhrase] = useState(false)
  const [results, setResults] = useState([])
  const [loading, setLoading] = useState(true)
  const [suggestion, setSuggestion] = useState(null)
  const requestId = useRef(0)

  const runSearch = useCallback(async (q, cat, sort, phrase) => {
    const currentRequest = ++requestId.current
    setLoading(true)
    const [searchResults, fuzzy] = await Promise.all([
      searchArticles(q, { category: cat, sortBy: sort, exactPhrase: phrase }),
      phrase ? Promise.resolve(null) : getFuzzySuggestions(q),
    ])
    if (currentRequest !== requestId.current) return
    setResults(searchResults)
    setSuggestion(fuzzy)
    setLoading(false)
  }, [])

  useEffect(() => {
    runSearch(activeQuery, category, sortBy, exactPhrase)
  }, [activeQuery, category, sortBy, exactPhrase, runSearch])

  useEffect(() => {
    const params = {}
    if (activeQuery) params.q = activeQuery
    if (category !== 'All') params.category = category
    setSearchParams(params, { replace: true })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeQuery, category])

  const handleSubmit = (value) => {
    setActiveQuery(value.trim())
  }

  const applySuggestion = () => {
    setQuery(suggestion)
    setActiveQuery(suggestion)
  }

  const resultLabel = activeQuery
    ? `${results.length} result${results.length === 1 ? '' : 's'} for "${activeQuery}"`
    : `Showing ${results.length} recent articles`

  return (
    <div className="page">
      <section className="explore-hero container">
        <h1>Search the archive</h1>
        <SearchBar
          value={query}
          onChange={setQuery}
          onSubmit={handleSubmit}
          size="lg"
          showExactPhrase
          exactPhrase={exactPhrase}
          onToggleExactPhrase={(checked) => setExactPhrase(checked)}
          placeholder="Try “artificial intelligence” or an exact phrase like “interest rates”…"
        />

        {suggestion && (
          <button className="fuzzy-suggestion" onClick={applySuggestion}>
            <FiSearch />
            Did you mean: <strong>{suggestion}</strong>?
          </button>
        )}
      </section>

      <section className="container">
        <FilterBar category={category} onCategoryChange={setCategory} sortBy={sortBy} onSortChange={setSortBy} />

        {!loading && <p className="explore-count">{resultLabel}</p>}

        <ArticleGrid
          results={results}
          loading={loading}
          skeletonCount={6}
          emptyState={
            <EmptyState
              title="No matching articles"
              description={`We couldn't find anything for "${activeQuery}". Check the spelling or try a broader term.`}
            />
          }
        />
      </section>
    </div>
  )
}
