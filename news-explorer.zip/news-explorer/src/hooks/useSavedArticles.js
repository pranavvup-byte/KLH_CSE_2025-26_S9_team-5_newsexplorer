import { useCallback, useEffect, useState } from 'react'

const STORAGE_KEY = 'news-explorer:saved-articles'

function readStorage() {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY)
    return raw ? JSON.parse(raw) : []
  } catch {
    return []
  }
}

/**
 * Keeps the list of saved article ids in sync with localStorage, and
 * broadcasts changes across every component using this hook (via a custom
 * event) so the header, saved page and article cards all stay in sync.
 */
export function useSavedArticles() {
  const [savedIds, setSavedIds] = useState(readStorage)

  useEffect(() => {
    const handleChange = () => setSavedIds(readStorage())
    window.addEventListener('news-explorer:saved-changed', handleChange)
    return () => window.removeEventListener('news-explorer:saved-changed', handleChange)
  }, [])

  const persist = useCallback((next) => {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next))
    setSavedIds(next)
    window.dispatchEvent(new Event('news-explorer:saved-changed'))
  }, [])

  const isSaved = useCallback((id) => savedIds.includes(id), [savedIds])

  const toggleSaved = useCallback((id) => {
    const next = savedIds.includes(id)
      ? savedIds.filter((savedId) => savedId !== id)
      : [...savedIds, id]
    persist(next)
    return next.includes(id)
  }, [savedIds, persist])

  const removeSaved = useCallback((id) => {
    persist(savedIds.filter((savedId) => savedId !== id))
  }, [savedIds, persist])

  return { savedIds, isSaved, toggleSaved, removeSaved }
}
