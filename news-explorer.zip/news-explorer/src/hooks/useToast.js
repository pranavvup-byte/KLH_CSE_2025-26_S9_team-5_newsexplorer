import { useEffect, useState } from 'react'

const EVENT_NAME = 'news-explorer:toast'

export function showToast(message) {
  window.dispatchEvent(new CustomEvent(EVENT_NAME, { detail: message }))
}

/** Renders in App.jsx once; listens for showToast() calls from anywhere. */
export function useToastListener() {
  const [message, setMessage] = useState(null)

  useEffect(() => {
    let timeoutId
    const handle = (event) => {
      setMessage(event.detail)
      clearTimeout(timeoutId)
      timeoutId = setTimeout(() => setMessage(null), 2200)
    }
    window.addEventListener(EVENT_NAME, handle)
    return () => {
      window.removeEventListener(EVENT_NAME, handle)
      clearTimeout(timeoutId)
    }
  }, [])

  return message
}
